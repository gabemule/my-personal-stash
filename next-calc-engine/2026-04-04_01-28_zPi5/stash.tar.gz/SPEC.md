# Calc Engine Builder — Especificação do Projeto

## Visão Geral

Interface visual + motor de execução para construir e executar **motores de cálculo** financeiros/securitários.

O Builder **gera** o JSON de configuração do motor. O Runtime (`lib/runtime/`) **executa** esse JSON com os inputs fornecidos e retorna os resultados.

**Casos de uso típicos:** cálculo de prêmios de seguro, tarifas, agravo de risco, fatores de ajuste.

> **Nota:** O runtime está embutido em `lib/runtime/` durante a fase de validação do modelo. Quando validado, será extraído e publicado como pacote npm independente.

---

## Estrutura do Projeto

```
calc-engine-builder/
├── package.json              ← projeto Next.js (sem workspaces)
├── SPEC.md                   ← este arquivo
│
├── app/                      ← rotas Next.js App Router
│   ├── api/                  ← API routes ativas (Supabase)
│   │   ├── engines/          ← GET + POST /api/engines
│   │   │   ├── active/       ← GET /api/engines/active
│   │   │   └── [id]/         ← PATCH + DELETE /api/engines/:id
│   │   │       └── activate/ ← POST /api/engines/:id/activate
│   │   ├── projects/         ← GET + POST /api/projects
│   │   │   ├── active/       ← GET /api/projects/active
│   │   │   └── [id]/         ← PATCH + DELETE /api/projects/:id
│   │   │       └── activate/ ← POST /api/projects/:id/activate
│   │   ├── calc/[id]/        ← POST /api/calc/:id
│   │   └── schema/           ← GET /api/schema
│   ├── builder/              ← /builder (entrada principal)
│   │   └── components/       ← componentes específicos da rota
│   ├── engines/              ← /engines
│   ├── projects/             ← /projects
│   ├── calc/                 ← /calc
│   │   └── components/       ← componentes específicos da rota
│   └── guide/                ← /guide
│       └── components/       ← componentes específicos da rota
│
├── components/               ← componentes globais (reutilizáveis)
│   ├── GlobalLoading/        ← overlay de loading global
│   ├── Modal/                ← wrapper dialog genérico
│   └── ProjectSwitcher/      ← dropdown global de troca de projeto
├── hooks/
├── lib/
│   ├── runtime/              ← motor de execução (embutido durante validação)
│   │   ├── types.ts          ← schema JSON completo
│   │   ├── decimalFactory.ts
│   │   ├── evaluator.ts
│   │   ├── execute.ts        ← execute(engine, inputs, options)
│   │   ├── schema.ts         ← EngineSchema (Zod)
│   │   └── index.ts          ← API pública
│   ├── supabase.ts           ← singleton do cliente Supabase
│   ├── types.ts
│   ├── stateUtils.ts
│   └── exportState.ts
├── stores/                   ← engineStore.ts (Zustand, API-backed)
├── db/
│   ├── schema.sql            ← DDL das tabelas (versionado)
│   └── rls.sql               ← Row Level Security
└── bruno/                    ← collection de testes da API
```

> **Projeto Next.js standalone.** Monorepo removido para simplificar a fase de validação. Runtime embutido em `lib/runtime/` — sem build separado, sem workspace. `yarn dev` / `yarn build` direto na raiz.

---

## API do Runtime (`lib/runtime/`)

```ts
import { execute } from '@/lib/runtime'

const result = execute(engineJson, {
  capital: '100000',
  idade: '35',
})

// result.success     → true | false
// result.steps       → StepResult[]
// result.finalValue  → resultado da última etapa habilitada
```

```ts
interface ExecuteResult {
  success: boolean
  steps: StepResult[]
  finalValue: string | null
  error?: string          // erro global (ex: JSON inválido)
  validationErrors?: ZodIssue[]
}

interface StepResult {
  id: string
  name: string
  enabled: boolean
  value: string | null    // null se desativada ou com erro
  error: string | null
  trace?: StepTrace       // presente apenas com debug: true
}
```

**Uso server-side (Node / Next.js API Route / Lambda):**
```ts
import { execute } from '@/lib/runtime'  // local durante validação; npm quando publicado

// engine salvo no banco de dados como JSON
const engine = await supabase.from('engines').select('engine').eq('id', id).single()
const result = execute(engine.data.engine, req.body.inputs, { debug: true })
res.json(result)
```

---

## Conceitos do Motor

> ### Dois tipos de tabelas — distinção importante
>
> No contexto deste projeto existem **dois conceitos de "tabela"** que não devem ser confundidos:
>
> | Tipo | Nome interno | Para que serve |
> |------|-------------|----------------|
> | **Tabela de condicionais** | `LookupTable` (`tables`) | Avalia condições numéricas sequencialmente e retorna um valor — é usada como token em expressões de cálculo (ex: buscar taxa por faixa de faturamento) |
> | **Tabela de variáveis** | *(a definir)* | Representa um conjunto de parâmetros estruturados (ex: coeficientes por segmento, classes de produto) — ainda não modelada no schema |

---

### Variáveis (`variables`)
Valores nomeados com um valor padrão, unidade opcional e classificação de tipo.
```json
{ "id": "v1", "name": "faturamento", "defaultValue": "75000", "unit": "R$", "kind": "input" }
{ "id": "v3", "name": "coef_agravo", "defaultValue": "1.6", "kind": "constant" }
```
> `unit` é opcional — serve apenas como label visual (ex: `%`, `R$`, `anos`). Não afeta o cálculo.

> `kind` é opcional — `"input"` (padrão se omitido) indica valor fornecido pelo chamador em runtime; `"constant"` indica parâmetro fixo do motor (ex: taxa IOF, fator de agravo). A distinção é semântica e visual: a UI exibe apenas variáveis `"input"` no painel de teste (seção "Entradas"). Constantes são ocultas do TestPanel — seu valor padrão é sempre usado no cálculo. O runtime trata ambos da mesma forma (fallback para `defaultValue` se não fornecido).

### Tabelas de Condicionais (`tables`)
Tabelas de lookup multi-coluna com linhas condicionais. A primeira linha com condição verdadeira vence; uma linha com `condition: null` é o **default/else**.

Cada tabela tem `columns` (colunas com labels) e linhas com `values` mapeados por `columnId`. Um `tableRef` especifica qual coluna retornar.

**Caso de uso típico:** dada uma faixa de faturamento + uma classe de risco, retornar o prêmio básico correspondente.

```json
{
  "id": "t1",
  "name": "Premio Bruto por Faturamento",
  "columns": [
    { "id": "col1", "label": "Classe 1" },
    { "id": "col2", "label": "Classe 2" },
    { "id": "col3", "label": "Classe 3" }
  ],
  "rows": [
    {
      "id": "r1",
      "label": "Até 50k",
      "condition": { "left": { "kind": "varRef", "target": "v_fat" }, "op": "<=", "right": { "kind": "number", "value": "50000" } },
      "values": { "col1": "23.09", "col2": "34.63", "col3": "103.89" }
    },
    {
      "id": "r2",
      "label": "50k–100k",
      "condition": { "left": { "kind": "varRef", "target": "v_fat" }, "op": "<=", "right": { "kind": "number", "value": "100000" } },
      "values": { "col1": "23.09", "col2": "34.63", "col3": "103.89" }
    },
    {
      "id": "r3",
      "label": "Acima",
      "condition": null,
      "values": { "col1": "24.00", "col2": "36.02", "col3": "108.05" }
    }
  ]
}
```

> `label` em linhas é opcional — serve apenas como rótulo para leitura humana, não é usado no cálculo.

### Tabela de Variáveis — *a definir*

> **Em discussão.** Representa um conjunto estruturado de parâmetros que funcionam como variáveis, mas organizados em formato tabular — como os "COEFICIENTES DE AJUSTE" do CSV de referência:
>
> ```
> Segmento              | Coeficiente
> ----------------------|------------
> Operações             | 2.3
> Produtos Cl 1-2       | 1.6
> Produtos Cl 3-4       | 3.0
> Shopping              | 3.0
> ```
>
> Diferença da `LookupTable`: não usa condições numéricas — a linha é selecionada por **correspondência de categoria** (valor exato de uma variável de segmento). O modelo e a UI serão definidos após validação do modelo.

### Etapas (`steps`)
Linhas de cálculo nomeadas. Cada etapa contém uma **expressão** avaliada em ordem. Uma etapa pode referenciar o resultado de etapas anteriores.

`kind` opcional distingue o papel da etapa:
| Kind | Significado | UI |
|------|-------------|-----|
| `"output"` (padrão se omitido) | Resultado relevante — ex: prêmio final, prêmio base ajustado | Destacado nos resultados do TestPanel |
| `"internal"` | Etapa auxiliar / intermediária — ex: roteamento condicional, cálculo helper | Agrupado em seção "Internos" (muted) |

```json
{
  "id": "s1",
  "name": "Taxa Base",
  "enabled": true,
  "kind": "output",
  "expression": [
    { "type": "tableRef", "tableId": "t1", "columnId": "col1" },
    { "type": "op", "value": "*" },
    { "type": "varRef", "target": "v1" }
  ]
}
```

### Tokens de Expressão
| Tipo | Descrição | Exemplo |
|------|-----------|---------|
| `number` | Literal numérico | `"100"`, `"0.05"` |
| `varRef` | Referência a variável | `{ type: "varRef", target: "v1" }` |
| `stepRef` | Resultado de etapa anterior | `{ type: "stepRef", target: "s1" }` |
| `tableRef` | Lookup em tabela — retorna coluna específica | `{ type: "tableRef", tableId: "t1", columnId: "col1" }` |
| `op` | Operador: `+` `-` `*` `/` `%` | `{ type: "op", value: "*" }` |
| `paren` | Agrupamento `(` `)` | `{ type: "paren", value: "(" }` |
| `conditional` | IF / ELSE IF / ELSE multi-branch escalar | ver abaixo |

**Conditional token (multi-branch):**
```json
{
  "type": "conditional",
  "branches": [
    {
      "condition": { "left": { "kind": "varRef", "target": "v_classe" }, "op": "<=", "right": { "kind": "number", "value": "1" } },
      "value": { "type": "tableRef", "tableId": "t1", "columnId": "col1" }
    },
    {
      "condition": { "left": { "kind": "varRef", "target": "v_classe" }, "op": "<=", "right": { "kind": "number", "value": "2" } },
      "value": { "type": "tableRef", "tableId": "t1", "columnId": "col2" }
    }
  ],
  "elseToken": { "type": "tableRef", "tableId": "t1", "columnId": "col3" }
}
```
> `branches` é um array de `{condition, value}` — avaliados sequencialmente, o primeiro que satisfaz a condição vence. `elseToken` é o fallback obrigatório. Tanto `value` em cada branch quanto `elseToken` são `ScalarToken` (`number`, `varRef`, `stepRef`, `tableRef`).

> **TableConditionSide** (usado em condições de tabela e de `conditional`) suporta `varRef`, `stepRef` e `number` como operandos — permitindo usar o **resultado de uma etapa como condição de linha de tabela**. Exemplo: `{ "kind": "stepRef", "target": "s1" }` compara o resultado de `s1` com um número.

### Configuração (`config`)
| Campo | Tipo | Descrição |
|-------|------|-----------|
| `precision` | `number` (0–20) | Casas decimais no resultado final |
| `rounding` | `ROUND_HALF_UP` \| `ROUND_DOWN` \| `ROUND_HALF_EVEN` | Modo de arredondamento |
| `min` | `string \| null` | Piso de valor — aplicado apenas nas etapas com `clamp: true` |
| `max` | `string \| null` | Teto de valor — aplicado apenas nas etapas com `clamp: true` |

### Campo `clamp` nas Etapas
```json
{ "id": "s9", "name": "Prêmio Final com IOF", "kind": "output", "clamp": true, "enabled": true, "expression": [...] }
```
> `clamp` é opcional (`false` por padrão). Quando `true`, o resultado da etapa é submetido ao clamp `config.min` / `config.max` **antes de ser exibido**. O valor armazenado internamente (para `stepRef` por etapas seguintes) permanece **sem clamp** — apenas o display e o output final são afetados.
>
> Isso permite aplicar piso/teto apenas no prêmio final sem distorcer cálculos intermediários (ex: Valor do Desconto calculado sobre o prêmio sem clamp).

---

## JSON Schema Completo

```json
{
  "name": "Motor de Cálculo",
  "config": {
    "precision": 2,
    "rounding": "ROUND_HALF_UP",
    "min": null,
    "max": null
  },
  "variables": [...],
  "tables": [...],
  "steps": [...]
}
```

---

## Algoritmo de Execução

1. Validar `engine` com `EngineSchema.safeParse()` — retorna `validationErrors[]` se inválido
2. Resolver variáveis → `Record<varId, Decimal>`
3. Para cada etapa em ordem:
   - Se `enabled === false` → pular, marcar resultado como `null`
   - Avaliar `expression` via **Shunting-Yard → RPN → Decimal stack**
   - Aplicar `round()` → armazenar resultado **sem clamp** em contexto (disponível para `stepRef` nas etapas seguintes)
   - Se `step.clamp === true` → aplicar `clamp(min/max)` apenas no valor de output/display
4. Retornar resultados de todas as etapas

**Precedência de operadores:** `% * /` > `+ -` (todos left-associative)

**Tratamento de erros por etapa:** um erro em uma etapa não propaga para as próximas (resultado marcado como `null`).

**Modo debug** (`execute(engine, inputs, { debug: true })`): retorna `trace` por etapa com tokens resolvidos, branch IF vencedor e linha de tabela matchada.
- `TokenTrace`: `{ type, resolved, detail? }` — detalha cada token da expressão
- `StepResult.trace?: StepTrace` — presente apenas quando `debug: true`

---

## Funcionalidades

### Builder (`/builder`)

**Painel Esquerdo**
- **Variáveis:** CRUD com nome, valor padrão e unidade. Ao deletar, tokens `varRef` órfãos são removidos automaticamente das expressões.
  - Accordion independente com sub-seções Entradas e Constantes — cada uma pode ser aberta/fechada independentemente
- **Tabelas Lookup:** CRUD de tabelas. Clique abre um modal com grid editável:
  - Accordion independente (TABELAS LOOKUP)
  - Colunas configuráveis com labels (adicionar, renomear, reordenar, remover)
  - Linhas com label opcional, condição (left op right) ou padrão (else), e valor por coluna
  - Ao deletar tabela ou coluna, tokens `tableRef` órfãos são removidos automaticamente
- **Configurações (⚙):** modal com precision, rounding, min/max — acessível via botão no header

**Centro — Etapas**
- Cards com nome editável, toggle ON/OFF, reordenar (↑↓), deletar
- Strip de tokens com cores por tipo:
  - 🔵 `number` — azul
  - 🟢 `varRef` — verde
  - 🟣 `stepRef` — roxo
  - 🩵 `tableRef` — teal
  - 🟡 `conditional` — amarelo
  - ⚪ `op` / `paren` — cinza
- Footer fixo no card com botões de inserção por tipo de token, usando a cor de fundo do chip correspondente para identificação visual
- **Click-to-edit em todos os tokens:** clicar em qualquer pill abre o toolbar pré-preenchido com os valores atuais
- **Validação de sequência:** tokens inválidos são rejeitados com toast de erro inline (auto-dismiss 3.5s)
- Badge de aviso quando parênteses desbalanceados
- Tokens com referências quebradas destacados em vermelho
- Badge `min/max` clicável no cabeçalho do StepCard — `clamp` toggle amarelo quando ativo
- Toggle ON/OFF: ON verde, OFF vermelho — indica visualmente que a etapa está desabilitada
- Preview inline no header: exibe `= valor` (accent) ou `✕ erro` (vermelho) após calcular

**Painel Direito** — Accordion mutuamente exclusivo:
- **Testar Motor** (aberto por padrão): inputs por variável `"input"`, botão Calcular, resultados separados em "Resultados" (steps `output`) e "Internos" (steps `internal`)
  - Cálculo local via `execute()` — permite testar antes de salvar
- **JSON Preview** (fechado por padrão): atualização em tempo real, syntax highlight, copiar, download `.json`

**Ações Globais (header)**
- **Salvar:** persiste o motor e define como ativo no projeto
  - Botão desabilitado enquanto não há alterações não salvas
  - `*` aparece antes do nome (em itálico) quando há alterações pendentes
  - **Proteção contra nome duplicado:** modal "Nome já utilizado" com sugestão automática (`Motor A v2`, `v3`…)
- **Importar JSON:** modal com textarea — restaura estado completo
- **Limpar:** confirmação antes de apagar tudo

---

### Calculadora (`/calc`)

Execução via API server-side (`POST /api/calc/:id`):
- Inputs das variáveis `"input"` com valor padrão pré-preenchido
- Botão Calcular com loading state
- Resultados apenas das etapas marcadas como `"output"` e habilitadas
- **JSON Output:** seção colapsável com preview do payload de API (`engine`, `inputs`, `outputs`, `debug`) — botão copiar

---

### Biblioteca de Motores (`/engines`)

- Lista motores do projeto ativo, badge "ATIVO"
- Motor ativo → "Abrir builder" + "Calculadora"; motor inativo → "Definir ativo"
- Confirmação modal antes de excluir

---

### Projetos (`/projects`)

- CRUD de projetos com projeto ativo
- Um projeto ativo por vez — `setActiveProject(id)` desativa os demais
- `isActive` em `EngineRecord` é escopado ao projeto
- Ao deletar projeto, motores voltam para "Sem projeto" (`projectId: null`)
- **"Sem Projeto":** card especial para motores com `projectId === null`
- **ProjectSwitcher:** dropdown global em todas as telas para trocar projeto ativo (exibe "Sem Projeto" quando há motores sem projeto)

---

### Guia de Uso (`/guide`)

Página de referência para times atuarial e operacional:
- Sidebar TOC com scroll spy, layout duas colunas
- Tokens coloridos por tipo — mesmas cores do builder

---

## Banco de Dados (Supabase)

**Schema (`db/schema.sql`):**
```sql
create table projects (
  id         uuid primary key default gen_random_uuid(),
  name       text not null unique,
  is_active  boolean not null default false,
  created_at timestamptz not null default now()
);

create table engines (
  id          uuid primary key default gen_random_uuid(),
  name        text not null,
  engine      jsonb not null,
  is_active   boolean not null default false,
  project_id  uuid references projects(id) on delete set null,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  constraint engines_name_project_unique unique (name, project_id)
);
```

**RLS (`db/rls.sql`):** Row Level Security habilitado em ambas as tabelas. Acesso via `service_role` key (server-side) — não exposta ao cliente.

---

## API Routes (`app/api/`)

| Método | Rota | Ação |
|--------|------|------|
| `GET` | `/api/engines` | Lista motores (filtra por `?projectId=`) |
| `POST` | `/api/engines` | Cria motor — retorna `409 NAME_CONFLICT` se nome duplicado |
| `PATCH` | `/api/engines/:id` | Atualiza motor — `409` se conflito de nome |
| `DELETE` | `/api/engines/:id` | Remove motor |
| `POST` | `/api/engines/:id/activate` | Define ativo, desativa irmãos no projeto |
| `GET` | `/api/engines/active` | Retorna o motor ativo (`?projectId=` opcional; `404` se nenhum) |
| `GET` | `/api/projects` | Lista projetos |
| `POST` | `/api/projects` | Cria projeto |
| `PATCH` | `/api/projects/:id` | Renomeia projeto |
| `DELETE` | `/api/projects/:id` | Remove projeto (orphans engines) |
| `POST` | `/api/projects/:id/activate` | Define projeto ativo |
| `GET` | `/api/projects/active` | Retorna o projeto ativo (`404` se nenhum) |
| `POST` | `/api/calc/:id` | Executa cálculo server-side com debug |
| `GET` | `/api/schema` | Retorna JSON Schema do engine config (via `zod-to-json-schema`) |

O `NAME_CONFLICT` (409) é capturado pelo `EngineBuilder.handleSave()` que exibe o modal de nova versão.

---

## Store (`stores/engineStore.ts`)

Zustand API-backed — sem localStorage/persist:
- `records: EngineRecord[]` + `projects: Project[]` + `loading: boolean`
- `loadFromAPI()` — fetch `GET /api/engines` + `GET /api/projects`; guard contra chamadas concorrentes
- Optimistic updates: estado local atualizado imediatamente, API sincronizada em background
- Mapper snake_case → camelCase (Supabase → store)
- `setActiveProject(id)` chama a API e recarrega engines via `loadFromAPI()`
- **GlobalLoading:** overlay fixo lê `store.loading` — bloqueia interação durante carregamento global

---

## Collection Bruno (`bruno/`)

Testes da API em `bruno/` com ambientes `local` e `staging`:
- Requests: todos os endpoints de `engines`, `projects`, ativação, `schema` e `calc/:id`
- Variáveis de environment: `baseUrl`, `engineId`, `projectId`

---

## Roadmap

- [ ] Drag-and-drop para reordenar etapas (`REORDER_STEP` já existe no reducer; aguardando validação do modelo)
- [ ] Undo/Redo — histórico manual no `useEngineState` ou [`zundo`](https://github.com/charkour/zundo)
- [ ] **Tabela de Variáveis** — parâmetros estruturados por categoria (lookup direto por chave, sem condição numérica); requer alinhamento do schema JSON
- [ ] Cache de tabelas resolvidas (otimização para execuções em lote)
- [ ] Composição de motores (`stepRef` externo) — requer validação do modelo de execução em cadeia
- [ ] Publicar runtime como pacote npm (`@calc-engine/runtime`) — aguardando validação do modelo

---

## Tecnologias

| Tech | Versão | Escopo |
|------|--------|--------|
| Next.js | 16 | raiz |
| TypeScript | 5 | raiz |
| Tailwind CSS | 4 | raiz |
| Zustand | 5 | `stores/` |
| Decimal.js | 10 | `lib/runtime/` |
| Zod | 3 | `lib/runtime/` |
| zod-to-json-schema | 3 | `app/api/schema/` |
| Supabase JS | 2 | `lib/supabase.ts` + `app/api/` |
