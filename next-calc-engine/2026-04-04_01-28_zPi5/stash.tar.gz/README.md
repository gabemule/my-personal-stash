# <span style="font-size:1.5em">C</span>alc <span style="font-size:1.5em">E</span>ngine <span style="font-size:1.5em">B</span>uilder

Interface visual para construir e executar **motores de cálculo** financeiros e securitários.

O Builder gera um JSON de configuração do motor. O Runtime executa esse JSON com os inputs fornecidos e retorna os resultados — server-side, via API.

**Casos de uso:** cálculo de prêmios de seguro, tarifas, agravos de risco, fatores de ajuste.

---

## Rotas

| Rota | Descrição |
|------|-----------|
| `/builder` | Editor visual do motor de cálculo |
| `/calc` | Calculadora — executa o motor ativo via API |
| `/engines` | Biblioteca de motores do projeto ativo |
| `/projects` | CRUD de projetos |
| `/guide` | Guia de uso para times atuarial e operacional |

---

## Stack

- **Next.js 16** — App Router, API Routes server-side
- **TypeScript 5** + **Tailwind CSS 4**
- **Zustand 5** — store global API-backed + `persist` para seleção de workspace
- **Decimal.js** — aritmética de precisão arbitrária
- **Zod** — validação do schema do motor
- **Supabase** — banco de dados (PostgreSQL + RLS)

---

## Setup

### 1. Instalar dependências

```bash
yarn
```

### 2. Variáveis de ambiente

Crie um arquivo `.env.local` na raiz com base no `.env.example`:

```bash
cp .env.example .env.local
```

Preencha com as credenciais do Supabase:

```env
NEXT_PUBLIC_SUPABASE_URL=https://<project>.supabase.co
SUPABASE_ANON_KEY=<anon_key>
```

> A `anon` key é segura para uso público. Para operações privilegiadas server-side, use `SUPABASE_SERVICE_ROLE_KEY` (opcional).

### 3. Banco de dados

Execute os scripts SQL no Supabase SQL Editor:

```bash
db/schema.sql   # cria as tabelas projects e engines
db/rls.sql      # habilita Row Level Security
```

### 4. Rodar em desenvolvimento

```bash
yarn dev
```

Acesse [http://localhost:3000](http://localhost:3000) — redireciona para `/builder`.

---

## Docker

### Build da imagem

```bash
docker build -t next-calc-engine .
```

### Rodar localmente

O Dockerfile detecta automaticamente arquivos `.env.development`, `.env.staging` ou `.env.production` na raiz e os copia para `.env` e `.env.local` durante o build. Basta ter o arquivo correto presente antes de buildar.

```bash
docker run -p 80:80 next-calc-engine:latest
```

Acesse [http://localhost](http://localhost).

### Comandos úteis

```bash
# Build e run
docker build --no-cache -t next-calc-engine:latest . && docker run -p 80:80 next-calc-engine:latest

# Ver logs
docker logs next-calc

# Parar container
docker stop $(docker ps -q --filter ancestor=next-calc-engine:latest)

# Rebuild (após mudanças)
docker build -t next-calc-engine:latest . && docker run -p 80:80 next-calc-engine:latest
```

> **Nota:** A aplicação roda na porta 80 dentro do container (`yarn start -p 80`), mapeada para porta 80 do host.

---

## Runtime

O motor de cálculo está em `lib/runtime/` e é executado server-side via `POST /api/calc/:id`.

```ts
import { execute } from '@/lib/runtime'

const result = execute(engineJson, { capital: '100000', idade: '35' })
// result.success, result.steps, result.finalValue
```

> Durante a fase de validação o runtime está embutido no projeto. Após validação será publicado como pacote npm independente.

---

## API

| Método | Rota | Descrição |
|--------|------|-----------|
| `POST` | `/api/calc/:id` | Executa o motor (server-side) |
| `GET` | `/api/engines` | Lista motores |
| `POST` | `/api/engines` | Cria motor |
| `GET` | `/api/engines/active` | Motor ativo do projeto |
| `GET` | `/api/projects` | Lista projetos |
| `POST` | `/api/projects` | Cria projeto |
| `GET` | `/api/projects/active` | Projeto ativo |
| `GET` | `/api/schema` | JSON Schema do motor (via Zod) |

Collection Bruno disponível em `bruno/` com ambientes `local` e `staging`.

---

## Estrutura

```
app/
├── api/              ← API routes (Supabase + runtime)
├── builder/          ← Editor visual
├── calc/             ← Calculadora
├── engines/          ← Biblioteca de motores
├── projects/         ← Gestão de projetos
└── guide/            ← Guia de uso
components/           ← Componentes globais
lib/
├── runtime/          ← Motor de cálculo (Decimal.js + Zod)
└── supabase/         ← Client Supabase SSR (server-side)
stores/               ← engineStore + workspaceStore (Zustand)
proxy.ts              ← Middleware de auth (Supabase SSR refresh + proteção de rotas)
db/                   ← Schema SQL versionado
bruno/                ← Collection de testes da API (Setup → engines → calc)
```
